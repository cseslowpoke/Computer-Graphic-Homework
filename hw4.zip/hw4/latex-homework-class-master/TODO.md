# TODO

These are some features that I'd like to implement.

- [ ] `nofullpage` option to make the pages smaller
- [ ] `nounderline` option to remove lines from underneath question headers

If you have ideas for more things that I could implement or you've implemented
something yourself, make an Issue or a Pull Request, respectively!
